NintendoClawMachine ZIP
----------------------
This ZIP includes a PLACEHOLDER CIA file.

Why placeholder?
- Real CIA files must be built with devkitARM + makerom.
- On tablets, this is done via GitHub Actions.

How to get the real CIA:
1. Upload the NintendoClawMachine source to GitHub.
2. Use the provided GitHub Actions workflow.
3. Download the generated CIA artifact.

Once built, replace this placeholder CIA with the real one.
